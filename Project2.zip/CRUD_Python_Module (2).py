# Example Python Code to Insert a Document 

from pymongo import MongoClient 
from bson.objectid import ObjectId 
from pprint import pprint

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self, username, password,host, port, db, col): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        USER = username #aacuser 
        PASS = password #SNHU1234
        HOST = host 
        PORT = port 
        DB = db
        COL = col 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create a method to return the next available record number for use in the create method
            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        if data is not None: 
            result = self.database.animals.insert_one(data)  # data should be dictionary 
            
            #Will return true or false depending on result
            return result.acknowledged
            
        else: 
            raise Exception("Nothing to save, because data parameter is empty") 
            
            
 

    # Create method to implement the R in CRUD.
    def read(self, data):
        if data is not None: 
            result = self.database.animals.find(data)# data should be dictionary
            
            #Will return the list if found
            return list(result)
        else: 
            result = self.database.animals.find({}) 
            return list(result)
        
    # Update method
    def update(self, data, attribute, new):
        
        if data is not None:
            result = self.database.animals.update_many(data, {"$set": {"attribute": "new"}})
            print(data)
            print(attribute)
            print(new)
            print(result.matched_count)
            print(result.modified_count)
            print(result)  
            
            
        else:
            raise Exception("data not found")
            
    def delete(self, data) :
        if data is not None:
            result = self.database.animals.delete_many(data)
            print(result.deleted_count)